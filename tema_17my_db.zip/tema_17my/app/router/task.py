from fastapi import APIRouter

router_task = APIRouter(prefix="/tack", tags=["task"])


@router_task.get("/")
def all_tasks():
    pass


@router_task.get("/task_id")
def task_by_id():
    pass

@router_task.post("/create")
def create_task():
    pass

@router_task.put("/update")
def update_task():
    pass

@router_task.delete("/delete")
def delete_task():
    pass

